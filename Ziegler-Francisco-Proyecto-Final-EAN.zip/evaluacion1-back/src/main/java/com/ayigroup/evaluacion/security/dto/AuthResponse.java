package com.ayigroup.evaluacion.security.dto;

public record AuthResponse(
        String token
) {
}
