
package com.ayigroup.zieglerfrancisco.tipoUsuario;

public record TipoUsuarioDTO(
        int idTipoUsuario,
        String descripcion
        ) {}
