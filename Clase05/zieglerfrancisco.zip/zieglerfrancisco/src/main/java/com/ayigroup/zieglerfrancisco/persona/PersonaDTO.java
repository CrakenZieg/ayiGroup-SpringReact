
package com.ayigroup.zieglerfrancisco.persona;

public record PersonaDTO(
        int idPersona,
        String nombre,
        String apellido,
        int numeroDocumento
        ) {}
