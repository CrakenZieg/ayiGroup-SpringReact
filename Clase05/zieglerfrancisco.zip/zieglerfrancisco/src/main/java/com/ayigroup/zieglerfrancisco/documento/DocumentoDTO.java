
package com.ayigroup.zieglerfrancisco.documento;

public record DocumentoDTO(
        int numeroDocumento,
        String descripcion
        ) {}
