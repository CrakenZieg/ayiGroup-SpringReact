
package com.ayigroup.zieglerfrancisco;

import com.ayigroup.zieglerfrancisco.ui.Menu;

public class Zieglerfrancisco {

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.menu();
    }
}
