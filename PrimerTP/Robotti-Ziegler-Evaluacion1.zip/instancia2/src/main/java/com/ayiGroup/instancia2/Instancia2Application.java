package com.ayiGroup.instancia2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Instancia2Application {

	public static void main(String[] args) {
		SpringApplication.run(Instancia2Application.class, args);
	}

}
