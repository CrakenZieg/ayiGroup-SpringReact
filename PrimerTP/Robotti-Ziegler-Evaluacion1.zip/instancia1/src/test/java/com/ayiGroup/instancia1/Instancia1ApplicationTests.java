package com.ayiGroup.instancia1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Instancia1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
