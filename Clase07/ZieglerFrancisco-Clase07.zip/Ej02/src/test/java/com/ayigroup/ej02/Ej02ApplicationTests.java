package com.ayigroup.ej02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
