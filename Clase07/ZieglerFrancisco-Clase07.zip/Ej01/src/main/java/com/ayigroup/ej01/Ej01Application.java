package com.ayigroup.ej01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej01Application {

	public static void main(String[] args) {
		SpringApplication.run(Ej01Application.class, args);
	}

}
