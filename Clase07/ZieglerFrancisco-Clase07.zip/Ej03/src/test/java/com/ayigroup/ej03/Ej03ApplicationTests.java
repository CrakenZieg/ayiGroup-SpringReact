package com.ayigroup.ej03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
