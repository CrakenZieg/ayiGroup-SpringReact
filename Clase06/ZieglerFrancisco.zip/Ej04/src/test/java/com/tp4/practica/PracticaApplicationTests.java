package com.tp4.practica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
