package com.ayigroup.evaluacion.error.dto;

public record ExceptionDTO(
        String error
) {
}
